# 基于vue和elementUI的电商后台管理系统

## 依赖下载
```
yarn install
```

### 热更新运行项目
```
yarn serve
```

### 项目依赖
- vue v2.6.11
- axios v0.20.0
- elementUI v2.4.5
- vue-router 
- vue-table-with-tree-grid

### Lints and fixes files
```
yarn lint
```

### 写在最后
项目来源于开源教程。感兴趣的话可以联系我哟（2478731248@qq.com）
